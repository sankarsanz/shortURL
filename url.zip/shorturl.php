<?php
include_once 'GoogleUrlApi.php';
// Create instance with key
$key = 'AIzaSyBhziTM30ztdXenU1zeVn-kiSQy9Wj0nfU';
$googer = new GoogleURLAPI($key);

// Test: Shorten a URL
$shortDWName = $googer->shorten("https://davidwalsh.name");
echo $shortDWName; // returns http://goo.gl/i002

// Test: Expand a URL
$longDWName = $googer->expand($shortDWName);
echo $longDWName; // returns https://davidwalsh.name
?>